MANIFEST = {
    "name": "control_interno",
    "label": "Control y seguimiento",
    "summary": "Control interno, programa anual, evidencias, hallazgos y reportes.",
    "description": (
        "Modulo de control interno con vistas operativas, APIs y tableros para "
        "seguimiento de controles, programa anual, evidencias, hallazgos y "
        "reportes institucionales."
    ),
    "version": "1.0.0",
    "category": "Operaciones",
    "author": "SIPET",
    "sequence": "",
    "website": "https://avancoop.org",
    "route": "/control-seguimiento",
    "icon": "",
    "depends": [],
    "data": [
        "vistas/control.html",
        "vistas/tablero.html",
        "vistas/programa.html",
        "vistas/evidencia.html",
        "vistas/hallazgos.html",
        "vistas/reportes_ci.html",
    ],
    "assets": {
        "css": [],
        "js": [],
        "static_base_url": "/modulos/control_interno/static",
        "img": [
            "static/description/control.svg",
        ],
        "description": [
            "static/description/control.svg",
        ],
    },
    "structure": {
        "router": [
            "controladores/control.py",
            "controladores/tablero.py",
            "controladores/programa.py",
            "controladores/evidencia.py",
            "controladores/hallazgos.py",
            "controladores/reportes_ci.py",
        ],
        "models": [
            "modelos/models.py",
            "modelos/programa_models.py",
            "modelos/evidencia_models.py",
            "modelos/hallazgo_models.py",
        ],
        "service": [
            "modelos/store.py",
            "modelos/tablero_store.py",
            "modelos/programa_store.py",
            "modelos/evidencia_store.py",
            "modelos/hallazgo_store.py",
            "modelos/reporte_store.py",
        ],
    },
    "installable": True,
    "application": True,
    "auto_install": False,
}

__all__ = ["MANIFEST"]
