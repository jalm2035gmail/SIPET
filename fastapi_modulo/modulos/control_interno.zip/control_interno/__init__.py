from fastapi_modulo.modulos.control_interno.controladores.control import router

__all__ = ["router"]
